package demo01;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Goodsdao {
	/**
	 * ͼ����Ϣ��ѯ
	 * @param con
	 * @param goods
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,Goods goods)throws Exception{
		StringBuffer sb=new StringBuffer("select * from tb_Goods");
		if(goods.getGoodsID()!=0&&goods.getGoodsID()!=-1) {
			sb.append(" and goodsID like '%"+goods.getGoodsID()+"%'");
		}
		if(StringUtil.isNotEmpty(goods.getGoodsName())) {
			sb.append(" and goodsName like '%"+goods.getGoodsName()+"%'");
		}
		if(goods.getSuplierID()!=0&&goods.getSuplierID()!=-1) {
			sb.append(" and SuplierID like '%"+goods.getSuplierID()+"%'");
		}
		if(StringUtil.isNotEmpty(goods.getBarCode())) {
			sb.append(" and barCode like '%"+goods.getBarCode()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();	
	}
	
	public static int update(Connection con,Goods goods)throws Exception{
		String sql="update tb_Goods set goodsID=?,goodsName=?,goodsPrice=?,suplierID=?,promotionalPrice=?,proCreateTime=?,proEndTime=?,isDiscount=?,stockAlarm=?,quantityIn=?,barCode=?,remark=?where goodsID=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, goods.getGoodsID());
		pstmt.setString(2, goods.getGoodsName());
		pstmt.setDouble(3, goods.getGoodsPrice());
		pstmt.setInt(4, goods.getSuplierID());
		pstmt.setFloat(5, goods.getPromotionalPrice());
		pstmt.setDate(6, goods.getProCreateTime());
		pstmt.setDate(7, goods.getProEndTime());
		pstmt.setInt(8, goods.isDiscount());
		pstmt.setInt(9,goods.getStockAlarm());
		pstmt.setInt(10, goods.getQuantityIn());
		pstmt.setString(11, goods.getBarCode());
		pstmt.setString(12, goods.getRemark());
		pstmt.setInt(13, goods.getGoodsID());
		return pstmt.executeUpdate();	
		
	}
}
