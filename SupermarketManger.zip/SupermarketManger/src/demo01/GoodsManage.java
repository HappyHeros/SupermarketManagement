package demo01;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoodsManage extends JFrame {

	private JPanel contentPane;
	private JTable goodsTable;
	private JTextField goodsIDtextField;
	private JTextField goodsNametextField;
	private JTextField supliertextField;
	private JTextField BarCodetextField;
	private JTextField goodsidtextField;
	private JTextField goodsnametextField;
	private JTextField proEndTimetextField;
	private JTextField textField_7;
	private JTextField promotionalPricetextField;
	private JTextField quantityIntextField;
	private JTextField goodspricetextField;
	private JTextField stockAlarmtextField;
	private JTextField proCreateTimetextField;
	private JTextField suplieridtextField;
	private JTextField barCodetextField;
	private JRadioButton radioButton;//�ж��Ƿ񽵼�
	private JRadioButton radioButton_1; 
	private JTextArea remarktextArea;
	
	private Dbutil dbUtil=new Dbutil();
//	private Goods goods=new Goods();
    private Goodsdao goodsdao=new Goodsdao();
    
    /**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GoodsManage frame = new GoodsManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GoodsManage() {
		setTitle("\u8D27\u7269\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1137, 826);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u4FE1\u606F\u68C0\u7D22", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u8868\u5355\u4FEE\u6539", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(53)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(Alignment.LEADING, gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(panel, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
							.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 986, Short.MAX_VALUE)))
					.addContainerGap(72, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(31)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 199, GroupLayout.PREFERRED_SIZE)
					.addGap(40)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 335, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(55, Short.MAX_VALUE))
		);
		
		JLabel label_3 = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_3.setBounds(25, 46, 60, 15);
		
		goodsidtextField = new JTextField();
		goodsidtextField.setBounds(95, 43, 123, 21);
		goodsidtextField.setColumns(10);
		
		JLabel label_4 = new JLabel("\u5546\u54C1\u540D\u79F0\uFF1A");
		label_4.setBounds(263, 46, 60, 15);
		
		goodsnametextField = new JTextField();
		goodsnametextField.setBounds(333, 43, 123, 21);
		goodsnametextField.setColumns(10);
		
		JLabel label_6 = new JLabel("\u5546\u54C1\u4EF7\u683C\uFF1A");
		label_6.setBounds(497, 46, 60, 15);
		
		proEndTimetextField = new JTextField();
		proEndTimetextField.setBounds(578, 87, 123, 21);
		proEndTimetextField.setColumns(10);
		
		JLabel label_7 = new JLabel("\u4F9B\u5E94\u5546\u7F16\u53F7\uFF1A");
		label_7.setBounds(741, 46, 72, 15);
		
		textField_7 = new JTextField();
		textField_7.setBounds(1418, 43, 123, 21);
		textField_7.setColumns(10);
		
		JLabel label_8 = new JLabel("\u4FC3\u9500\u4EF7\u683C\uFF1A");
		label_8.setBounds(25, 90, 60, 15);
		
		JLabel label_9 = new JLabel("\u4FC3\u9500\u59CB\u65E5\u671F\uFF1A");
		label_9.setBounds(263, 90, 82, 15);
		
		JLabel label_10 = new JLabel("\u4FC3\u9500\u6B62\u65E5\u671F\uFF1A");
		label_10.setBounds(497, 90, 82, 15);
		
		JLabel label_11 = new JLabel("\u662F\u5426\u5141\u8BB8\u6253\u6298\uFF1A");
		label_11.setBounds(741, 90, 96, 15);
		
		JLabel label_12 = new JLabel("\u5E93\u5B58\u62A5\u8B66\u6570\u91CF\uFF1A");
		label_12.setBounds(28, 131, 106, 15);
		
		JLabel label_13 = new JLabel("\u8BA1\u5212\u8FDB\u8D27\u6570\uFF1A");
		label_13.setBounds(263, 131, 83, 15);
		
		JLabel label_14 = new JLabel("\u6761\u5F62\u7801\uFF1A");
		label_14.setBounds(497, 131, 82, 15);
		
		promotionalPricetextField = new JTextField();
		promotionalPricetextField.setBounds(95, 87, 123, 21);
		promotionalPricetextField.setColumns(10);
		
		quantityIntextField = new JTextField();
		quantityIntextField.setBounds(333, 128, 123, 21);
		quantityIntextField.setColumns(10);
		
		goodspricetextField = new JTextField();
		goodspricetextField.setBounds(578, 43, 123, 21);
		goodspricetextField.setColumns(10);
		
		stockAlarmtextField = new JTextField();
		stockAlarmtextField.setBounds(135, 131, 83, 21);
		stockAlarmtextField.setColumns(10);
		
		proCreateTimetextField = new JTextField();
		proCreateTimetextField.setBounds(333, 87, 123, 21);
		proCreateTimetextField.setColumns(10);
		
		suplieridtextField = new JTextField();
		suplieridtextField.setBounds(827, 43, 123, 21);
		suplieridtextField.setColumns(10);
		
		JLabel label_15 = new JLabel("\u5907\u6CE8\uFF1A");
		label_15.setBounds(25, 177, 36, 15);
		
		 remarktextArea = new JTextArea();
		remarktextArea.setBounds(95, 173, 467, 76);
		
		JButton button_2 = new JButton("\u4FEE\u6539");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				goodsUpdateActionPerformed(evt);
			}
		});
		button_2.setBounds(174, 259, 203, 37);
		
		JButton button_3 = new JButton("\u91CD\u7F6E");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eet) {
				goodsUpdateEmptyActionPerformed(eet);
			}
		});
		button_3.setBounds(575, 257, 220, 39);
		panel_1.setLayout(null);
		panel_1.add(label_15);
		panel_1.add(remarktextArea);
		panel_1.add(label_3);
		panel_1.add(goodsidtextField);
		panel_1.add(label_8);
		panel_1.add(promotionalPricetextField);
		panel_1.add(label_12);
		panel_1.add(stockAlarmtextField);
		panel_1.add(label_4);
		panel_1.add(label_13);
		panel_1.add(label_9);
		panel_1.add(quantityIntextField);
		panel_1.add(proCreateTimetextField);
		panel_1.add(goodsnametextField);
		panel_1.add(label_6);
		panel_1.add(label_7);
		panel_1.add(label_10);
		panel_1.add(goodspricetextField);
		panel_1.add(proEndTimetextField);
		panel_1.add(label_14);
		panel_1.add(suplieridtextField);
		panel_1.add(button_2);
		panel_1.add(label_11);
		panel_1.add(textField_7);
		panel_1.add(button_3);
		
		barCodetextField = new JTextField();
		barCodetextField.setColumns(10);
		barCodetextField.setBounds(578, 128, 123, 21);
		panel_1.add(barCodetextField);
		
		 radioButton = new JRadioButton("\u662F");
		radioButton.setBounds(846, 86, 51, 23);
		panel_1.add(radioButton);
		
		radioButton_1 = new JRadioButton("\u5426");
		radioButton_1.setBounds(899, 86, 51, 23);
		panel_1.add(radioButton_1);
		
		JLabel label = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		
		JLabel label_1 = new JLabel("\u5546\u54C1\u540D\u79F0\uFF1A");
		
		JLabel label_5 = new JLabel("\u6761\u5F62\u7801\uFF1A");
		
		JLabel label_2 = new JLabel("\u4F9B\u5E94\u5546\u7F16\u53F7\uFF1A");
		
		goodsIDtextField = new JTextField();
		goodsIDtextField.setColumns(10);
		
		goodsNametextField = new JTextField();
		goodsNametextField.setColumns(10);
		
		supliertextField = new JTextField();
		supliertextField.setColumns(10);
		
		BarCodetextField = new JTextField();
		BarCodetextField.setColumns(10);
		
		JButton searchbutton = new JButton("\u67E5\u627E");
		searchbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goodsSearchActionPerformed(e);
			}
		});
		
		JButton emptybutton = new JButton("\u6E05\u7A7A");
		emptybutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eat) {
				goodsSearchResetActionPerformed(eat);
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addGap(85)
							.addComponent(searchbutton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addContainerGap()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(goodsIDtextField, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)))
					.addGap(16)
					.addComponent(label_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(goodsNametextField, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_2)
							.addGap(18)
							.addComponent(supliertextField, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
							.addGap(40)
							.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(BarCodetextField, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE))
						.addComponent(emptybutton, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE))
					.addGap(130))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(label_5)
						.addComponent(goodsIDtextField, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
						.addComponent(goodsNametextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(supliertextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(BarCodetextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(label_1))
					.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(searchbutton)
						.addComponent(emptybutton))
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
		
		goodsTable = new JTable();
		goodsTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent met) {
				goodsTableMousePressed(met);
			}
		});
		goodsTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u7F16\u53F7", "\u5546\u54C1\u540D\u79F0", "\u5546\u54C1\u4EF7\u683C", "\u4F9B\u5E94\u5546\u7F16\u53F7", "\u4FC3\u9500\u4EF7\u683C", "\u4FC3\u9500\u59CB\u65E5\u671F", "\u4FC3\u9500\u6B62\u65E5\u671F", "\u662F\u5426\u5141\u8BB8\u6253\u6298", "\u5E93\u5B58\u62A5\u8B66\u6570\u91CF", "\u8BA1\u5212\u8FDB\u8D27\u6570", "\u6761\u5F62\u7801", "\u5907\u6CE8"
			}
		));
		scrollPane.setViewportView(goodsTable);
		contentPane.setLayout(gl_contentPane);
	
		this.fillTable(new Goods());
	}
	/**
	 * ������Ʒ�޸��¼�
	 * @param eet
	 */
	protected void goodsUpdateEmptyActionPerformed(ActionEvent eet) {
		resetValue();
	}

	/**
	 * ��ղ�ѯ
	 * @param eat
	 */
	protected void goodsSearchResetActionPerformed(ActionEvent eat) {
		this.goodsIDtextField.setText("");
		this.goodsNametextField.setText("");
		this.supliertextField.setText("");
		this.BarCodetextField.setText("");
	}

	/**
	 * ��Ʒ��Ϣ�޸��¼�
	 * @param evt
	 */
	private void goodsUpdateActionPerformed(ActionEvent evt) {
	    String goodsid=this.goodsidtextField.getText();
	    if(StringUtil.isEmpty(goodsid)) {
	    	JOptionPane.showMessageDialog(null, "��ѡ��Ҫ�޸ĵļ�¼");
	    	return;
	    }
	    
	    String goodsname=this.goodsnametextField.getText();
	    String goodsprice=this.goodspricetextField.getText();
	    String suplierid=this.suplieridtextField.getText();
	    if(StringUtil.isEmpty(goodsname)) {
	    	JOptionPane.showMessageDialog(null, "��Ʒ���Ʋ���Ϊ�գ�");
	    	return;
	    }
	    if(StringUtil.isEmpty(goodsprice)) {
	    	JOptionPane.showMessageDialog(null, "��Ʒ�۸���Ϊ�գ�");
	    	return;
	    }
	    if(StringUtil.isEmpty(suplierid)) {
	    	JOptionPane.showMessageDialog(null, "��Ʒ��Ӧ�̱�Ų���Ϊ�գ�");
	    	return;
	    }
	    
	    String promotionalprice=this.promotionalPricetextField.getText();
	    String  procreatetime=this.proCreateTimetextField.getText();
	    String proendtime=this.proEndTimetextField.getText();
	    String isdiscount = null;
	    if(radioButton.isSelected()) {
	    	isdiscount="1";
	    }else if(radioButton_1.isSelected()) {
	    	isdiscount="0";
	    }
	    String stockalarm=this.stockAlarmtextField.getText();
	    String quantityin=this.quantityIntextField.getText();
	    String barcode=this.barCodetextField.getText();
	    String remark=this.remarktextArea.getText();
	    
	    Goods goods=new Goods(Integer.parseInt(goodsid),goodsname,Double.parseDouble(goodsprice),Integer.parseInt(suplierid),Float.parseFloat(promotionalprice),Date.valueOf(procreatetime),Date.valueOf(proendtime),Integer.parseInt(isdiscount),Integer.parseInt(stockalarm),Integer.parseInt(quantityin),barcode,remark);
	
	    Connection con=null;
	    try {
			con=dbUtil.getCon();
			int addNum=Goodsdao.update(con,goods);
			if(addNum==1) {
				JOptionPane.showMessageDialog(null, "��Ʒ�޸ĳɹ���");
				resetValue();
				this.fillTable(new Goods());
			}else {
				JOptionPane.showMessageDialog(null, "��Ʒ�޸�ʧ�ܣ�");
			}
			} catch (Exception e) {
			   e.printStackTrace();
			   JOptionPane.showMessageDialog(null, "��Ʒ�޸�ʧ�ܣ�");
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public void resetValue(){
		this.goodsidtextField.setText("");
		this.goodsnametextField.setText("");
		this.goodspricetextField.setText("");
		this.suplieridtextField.setText("");
		this.promotionalPricetextField.setText("");
		this.proCreateTimetextField.setText("");
		this.proEndTimetextField.setText("");
		this.radioButton.setSelected(true);
		this.stockAlarmtextField.setText("");
	    this.quantityIntextField.setText("");
	    this.barCodetextField.setText("");
	    this.remarktextArea.setText("");

		
	}

	/**
	 * �����е���¼�����
	 * @param met
	 */
	private void goodsTableMousePressed(MouseEvent met) {
		int row=this.goodsTable.getSelectedRow();
		this.goodsidtextField.setText((int)goodsTable.getValueAt(row, 0)+"");
		this.goodsnametextField.setText((String)goodsTable.getValueAt(row, 1));
		this.goodspricetextField.setText((double)goodsTable.getValueAt(row, 2)+"");
		this.suplieridtextField.setText((int)goodsTable.getValueAt(row, 3)+"");
		this.promotionalPricetextField.setText((float)goodsTable.getValueAt(row, 4)+"");
		this.proCreateTimetextField.setText((Date)goodsTable.getValueAt(row, 5)+"");
		this.proEndTimetextField.setText((Date)goodsTable.getValueAt(row, 6)+"");
		int isdiscount=(int)goodsTable.getValueAt(row, 7);
		if(isdiscount==1) {
			this.radioButton.setSelected(true);
		}else if(isdiscount==0) {
			this.radioButton_1.setSelected(true);
		}
		this.stockAlarmtextField.setText((int)goodsTable.getValueAt(row, 8)+"");
		this.quantityIntextField.setText((int)goodsTable.getValueAt(row, 9)+"");
		this.barCodetextField.setText((String)goodsTable.getValueAt(row, 10));
		this.remarktextArea.setText((String)goodsTable.getValueAt(row, 11));
	}

	/**
	 * ��Ʒ�����¼�����
	 * @param evt
	 */
	private  void goodsSearchActionPerformed(ActionEvent evt) {
		String goodsID=this.goodsIDtextField.getText();
		Integer goodsid=0;
		if(!goodsID.equals("")) {
			 goodsid=Integer.valueOf(goodsID);
			}
		
		String goodsName=this.goodsNametextField.getText();
		
		String suplierID=this.supliertextField.getText();
		Integer suplierid=0;
		if(!suplierID.equals("")) {
			suplierid=Integer.valueOf(suplierID);
		}
		
		String barcode=this.BarCodetextField.getText();
		Goods goods=new Goods(goodsid,goodsName,suplierid,barcode);	
		this.fillTable(goods);
		
	}

	/**
	 * ��ʼ������
	 * @param goods
	 */
	public void fillTable(Goods goods) {
		DefaultTableModel dtm=(DefaultTableModel) goodsTable.getModel();
		dtm.setRowCount(0);//���ó�0��
		Connection con=null;
		try {
			con=dbUtil.getCon();
			ResultSet rs=goodsdao.list(con, goods);
			while(rs.next()) {
				Vector v=new Vector();
				v.add(rs.getInt("goodsID"));
				v.add(rs.getString("goodsName"));
				v.add(rs.getDouble("goodsPrice"));
				v.add(rs.getInt("suplierID"));
				v.add(rs.getFloat("promotionalPrice"));
				v.add(rs.getDate("proCreateTime"));
				v.add(rs.getDate("proEndTime"));
				v.add(rs.getInt("isDiscount"));
				v.add(rs.getInt("stockAlarm"));
				v.add(rs.getInt("quantityIn"));
				v.add(rs.getString("barCode"));
				v.add(rs.getString("remark"));
				dtm.addRow(v);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
}
