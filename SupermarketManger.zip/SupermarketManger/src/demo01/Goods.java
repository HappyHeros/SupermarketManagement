package demo01;

import java.sql.Date;

public class Goods {
      private int goodsID;//��Ʒ���
      private String goodsName;//��Ʒ����
      private double goodsPrice;//��Ʒ�۸�
      private int suplierID;//��Ӧ�̱��
      private float promotionalPrice;//�����۸�
      private Date proCreateTime;//����ʼ����
      private Date proEndTime;//����ֹ����
      private int isDiscount;//�Ƿ��������� 0:������1:������
      private int stockAlarm;//��汨������
      private int quantityIn;//�ƻ�������
      private String barCode;//������
      private String remark;//��ע
    
      public Goods() {
    	  super();
      }
      
	public Goods(Integer goodsID, String goodsName,Integer suplierID, String barCode) {
		super();
		this.goodsID = goodsID;
		this.goodsName = goodsName;
		this.suplierID = suplierID;
		this.barCode = barCode;
	}
	


	public Goods(int goodsID, String goodsName, double goodsPrice, int suplierID, float promotionalPrice,
			Date proCreateTime, Date proEndTime, int isDiscount, int stockAlarm, int quantityIn, String barCode,
			String remark) {
		super();
		this.goodsID = goodsID;
		this.goodsName = goodsName;
		this.goodsPrice = goodsPrice;
		this.suplierID = suplierID;
		this.promotionalPrice = promotionalPrice;
		this.proCreateTime = proCreateTime;
		this.proEndTime = proEndTime;
		this.isDiscount = isDiscount;
		this.stockAlarm = stockAlarm;
		this.quantityIn = quantityIn;
		this.barCode = barCode;
		this.remark = remark;
	}

	public int getGoodsID() {
		return goodsID;
	}
	public void setGoodsID(int goodsID) {
		this.goodsID = goodsID;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public double getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(double goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public int getSuplierID() {
		return suplierID;
	}
	public void setSuplierID(int suplierID) {
		this.suplierID = suplierID;
	}
	public float getPromotionalPrice() {
		return promotionalPrice;
	}
	public void setPromotionalPrice(float promotionalPrice) {
		this.promotionalPrice = promotionalPrice;
	}
	public Date getProCreateTime() {
		return proCreateTime;
	}
	public void setProCreateTime(Date proCreateTime) {
		this.proCreateTime = proCreateTime;
	}
	public Date getProEndTime() {
		return proEndTime;
	}
	public void setProEndTime(Date proEndTime) {
		this.proEndTime = proEndTime;
	}
	public int isDiscount() {
		return isDiscount;
	}
	public void setDiscount(int isDiscount) {
		this.isDiscount = isDiscount;
	}
	public int getStockAlarm() {
		return stockAlarm;
	}
	public void setStockAlarm(int stockAlarm) {
		this.stockAlarm = stockAlarm;
	}
	public int getQuantityIn() {
		return quantityIn;
	}
	public void setQuantityIn(int quantityIn) {
		this.quantityIn = quantityIn;
	}
	public String getBarCode() {
		return barCode;
	}
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
      
      
}
