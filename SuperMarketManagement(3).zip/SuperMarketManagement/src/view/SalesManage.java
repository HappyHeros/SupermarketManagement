package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.naming.directory.SearchControls;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SalesManage extends JFrame {

	private JPanel contentPane;
	private JTextField searchTextField;
	private JTable MembersListTable;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesManage frame = new SalesManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalesManage() {
		setTitle("\u9500\u552E\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(8, -31, 740, 525);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(176, 51, 72, 15);
		contentPane.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(52, 88, 619, 357);
		contentPane.add(scrollPane);
		setLocationRelativeTo(null);	//������ʾ
		
		MembersListTable = new JTable();
		MembersListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			//	selectedRow(arg0);
			}
		});
		MembersListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"���۱��","��Ʒ���", "��������", "���۽��", "��������","��ע"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		MembersListTable.getColumnModel().getColumn(0).setPreferredWidth(40);
		MembersListTable.getColumnModel().getColumn(1).setPreferredWidth(40);
		MembersListTable.getColumnModel().getColumn(2).setPreferredWidth(40);
		MembersListTable.getColumnModel().getColumn(3).setPreferredWidth(60);
		MembersListTable.getColumnModel().getColumn(4).setPreferredWidth(80);
		MembersListTable.getColumnModel().getColumn(5).setPreferredWidth(50);
		
		scrollPane.setViewportView(MembersListTable);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(258, 48, 157, 21);
		contentPane.add(searchTextField);
		searchTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
//��ѯ����
//		searchButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent arg0) {
//				StudentMember serchText= new StudentMember();
//				serchText.setName(searchTextField.getText().toString());
//				setTable(serchText);
//			}
//		});
		searchButton.setBounds(452, 47, 77, 23);
		contentPane.add(searchButton);
		
		//��ʼ��table
//		setTable(new StudentMember());
	}
}
