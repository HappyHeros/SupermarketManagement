package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class SellerFrm extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SellerFrm frame = new SellerFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SellerFrm() {
		setTitle("\u6536\u94F6\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 344);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u4F1A\u5458\u5361\u53F7\uFF1A");
		label.setBounds(43, 27, 66, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_1.setBounds(43, 69, 66, 15);
		contentPane.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(119, 24, 255, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u7ED3\u7B97");
		button.setBounds(93, 250, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u6E05\u7A7A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_1.setBounds(299, 250, 93, 23);
		contentPane.add(button_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(119, 69, 257, 91);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		textArea.setText("\u8BF7\u5728\u6B64\u5904\u624B\u52A8\u8F93\u5165\u5546\u54C1\u7F16\u53F7");
		scrollPane.setViewportView(textArea);
		
		JLabel label_2 = new JLabel("\u5171\u8BA1\uFF1A");
		label_2.setBounds(43, 182, 54, 15);
		contentPane.add(label_2);
		
		textField_1 = new JTextField();
		textField_1.setText("\uFF1F\u5143");
		textField_1.setColumns(10);
		textField_1.setBounds(119, 179, 255, 21);
		contentPane.add(textField_1);
		
		JLabel label_3 = new JLabel("\u65E5\u671F\uFF1A");
		label_3.setBounds(43, 222, 54, 15);
		contentPane.add(label_3);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(119, 219, 255, 21);
		contentPane.add(textField_2);
	}

}
