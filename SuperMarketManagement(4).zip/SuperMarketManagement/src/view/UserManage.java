package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.naming.directory.SearchControls;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UserManage extends JFrame {

	private JPanel contentPane;
	private JTextField searchTextField;
	private JTable ListTable;
	private JTextField editUserNameTextField;
	private JTextArea editInfoTextArea;
	private JTextField UserPasswordTextField;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserManage frame = new UserManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserManage() {
		setTitle("\u7528\u6237\u7BA1\u7406\u8868");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 650, 545);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7528\u6237\u540D\u79F0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(132, 51, 72, 15);
		contentPane.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(98, 100, 459, 197);
		contentPane.add(scrollPane);
		
		ListTable = new JTable();
		ListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				selectedRow(arg0);
			}
		});
		ListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"�û����", "�û�����", "�û�����","��ע"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		ListTable.getColumnModel().getColumn(0).setPreferredWidth(50);
		ListTable.getColumnModel().getColumn(1).setPreferredWidth(50);
		ListTable.getColumnModel().getColumn(2).setPreferredWidth(60);
		ListTable.getColumnModel().getColumn(3).setPreferredWidth(120);
		
		scrollPane.setViewportView(ListTable);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(208, 48, 157, 21);
		contentPane.add(searchTextField);
		searchTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		searchButton.setBounds(401, 47, 77, 23);
		contentPane.add(searchButton);
		
		JLabel label_1 = new JLabel("\u7528\u6237\u540D\u79F0\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_1.setBounds(38, 336, 72, 15);
		contentPane.add(label_1);
		
		editUserNameTextField = new JTextField();
		editUserNameTextField.setColumns(10);
		editUserNameTextField.setBounds(98, 333, 130, 21);
		contentPane.add(editUserNameTextField);
		
		JLabel label_2 = new JLabel("\u5907\u6CE8\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_2.setBounds(38, 381, 72, 15);
		contentPane.add(label_2);
		
		editInfoTextArea = new JTextArea();
		editInfoTextArea.setLineWrap(true);
		editInfoTextArea.setTabSize(2);
		editInfoTextArea.setBounds(98, 377, 268, 102);
		contentPane.add(editInfoTextArea);
		
		JButton submitEditButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		submitEditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				submitEditAct(arg0);
			}
		});
		submitEditButton.setBounds(430, 402, 101, 23);
		contentPane.add(submitEditButton);
		
		JButton submitDeleteButton = new JButton("\u5220\u9664");
		submitDeleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteClassAct(e);
			}
		});
		submitDeleteButton.setBounds(430, 451, 101, 23);
		contentPane.add(submitDeleteButton);
		
		JLabel label_3 = new JLabel("\u7528\u6237\u5BC6\u7801\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_3.setBounds(264, 336, 72, 15);
		contentPane.add(label_3);
		
		UserPasswordTextField = new JTextField();
		UserPasswordTextField.setColumns(10);
		UserPasswordTextField.setBounds(328, 333, 130, 21);
		contentPane.add(UserPasswordTextField);
		
	}
	
	protected void deleteClassAct(ActionEvent e) {
		
	}

	protected void submitEditAct(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	protected void selectedRow(MouseEvent arg0) {
		
	}

}
