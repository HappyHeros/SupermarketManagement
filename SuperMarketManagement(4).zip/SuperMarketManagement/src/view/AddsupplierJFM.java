package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class AddsupplierJFM extends JFrame {

	private JPanel contentPane;
	private JTextField supplierNameTextField;
	private JTextArea classInfoTextField;
	private JTextField PhoneTextField;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
			//		StudentClassAddJFM frame = new StudentClassAddJFM()
			//   	frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddsupplierJFM() {
		String windows="com.sun.java.swing.plaf.windows.WindowsLookAndFeel"; 
		try {
			UIManager.setLookAndFeel(windows);
		} catch (Exception e) {	}
		
		
		setTitle("\u6DFB\u52A0\u4F9B\u5E94\u5546");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 557, 365);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel label = new JLabel("\u4F9B\u5E94\u5546\u540D\u79F0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(55, 43, 79, 26);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5907\u6CE8\u4FE1\u606F\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_1.setBounds(55, 144, 79, 26);
		contentPane.add(label_1);
		
		supplierNameTextField = new JTextField();
		supplierNameTextField.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		supplierNameTextField.setBounds(136, 46, 135, 21);
		contentPane.add(supplierNameTextField);
		supplierNameTextField.setColumns(10);
		
		JButton subButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		subButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//submitAct(e);
			}
		});
		subButton.setBounds(107, 272, 93, 23);
		contentPane.add(subButton);
		
		JButton cancleButton = new JButton("\u53D6\u6D88");
		cancleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cancleAct(arg0);
			}
		});
		cancleButton.setBounds(361, 272, 93, 23);
		contentPane.add(cancleButton);
		
		classInfoTextField = new JTextArea();
		classInfoTextField.setTabSize(2);
		classInfoTextField.setLineWrap(true);
		classInfoTextField.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		classInfoTextField.setBounds(136, 147, 306, 97);
		contentPane.add(classInfoTextField);
		
		JLabel label_2 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_2.setBounds(294, 43, 79, 26);
		contentPane.add(label_2);
		
		PhoneTextField = new JTextField();
		PhoneTextField.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		PhoneTextField.setColumns(10);
		PhoneTextField.setBounds(361, 46, 135, 21);
		contentPane.add(PhoneTextField);
		
		JLabel label_3 = new JLabel("\u4F9B\u5E94\u5546\u5730\u5740\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_3.setBounds(55, 94, 79, 26);
		contentPane.add(label_3);
		
		textField = new JTextField();
		textField.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		textField.setColumns(10);
		textField.setBounds(136, 95, 306, 26);
		contentPane.add(textField);
	}

	//�ύ����
//	protected void submitAct(ActionEvent e) {
//		// TODO Auto-generated method stub
//		String className=classNameTextField.getText().toString();
//		String classInfo=classInfoTextField.getText().toString();
//		if(StringUtil.isEmpty(className)) {
//			JOptionPane.showMessageDialog(this, "�༶���Ʋ���Ϊ�գ�");
//			return;
//		}
//		StudentClass class1=new StudentClass();
//		class1.setName(className);
//		class1.setInfo(classInfo);
//		ClassDao classDao=new ClassDao();
//		if(classDao.addClass(class1)) {
//			JOptionPane.showMessageDialog(this, "���ӳɹ���");
//		}else {
//			JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
//		}
//		classDao.closeDao();
//		resetValue(e);
//	}

	private void resetValue(ActionEvent e) {
		// TODO Auto-generated method stub
		supplierNameTextField.setText("");
		classInfoTextField.setText("");
	}

	protected void cancleAct(ActionEvent arg0) {
		// TODO Auto-generated method stub
		this.dispose();
	}
}
