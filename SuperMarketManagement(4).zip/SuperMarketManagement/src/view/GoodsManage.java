package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

public class GoodsManage extends JFrame {

	private JPanel contentPane;
	private JTable goodsTable;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GoodsManage frame = new GoodsManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GoodsManage() {
		setTitle("\u8D27\u7269\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1137, 826);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u4FE1\u606F\u68C0\u7D22", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u8868\u5355\u4FEE\u6539", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(53)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(Alignment.LEADING, gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(panel, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
							.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 986, Short.MAX_VALUE)))
					.addContainerGap(72, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(31)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 199, GroupLayout.PREFERRED_SIZE)
					.addGap(40)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 335, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(55, Short.MAX_VALUE))
		);
		
		JLabel label_3 = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_3.setBounds(25, 46, 60, 15);
		
		textField_4 = new JTextField();
		textField_4.setBounds(95, 43, 123, 21);
		textField_4.setColumns(10);
		
		JLabel label_4 = new JLabel("\u5546\u54C1\u540D\u79F0\uFF1A");
		label_4.setBounds(263, 46, 60, 15);
		
		textField_5 = new JTextField();
		textField_5.setBounds(333, 43, 123, 21);
		textField_5.setColumns(10);
		
		JLabel label_6 = new JLabel("\u5546\u54C1\u4EF7\u683C\uFF1A");
		label_6.setBounds(497, 46, 60, 15);
		
		textField_6 = new JTextField();
		textField_6.setBounds(578, 87, 123, 21);
		textField_6.setColumns(10);
		
		JLabel label_7 = new JLabel("\u4F9B\u5E94\u5546\u7F16\u53F7\uFF1A");
		label_7.setBounds(741, 46, 72, 15);
		
		textField_7 = new JTextField();
		textField_7.setBounds(1418, 43, 123, 21);
		textField_7.setColumns(10);
		
		JLabel label_8 = new JLabel("\u4FC3\u9500\u4EF7\u683C\uFF1A");
		label_8.setBounds(25, 90, 60, 15);
		
		JLabel label_9 = new JLabel("\u4FC3\u9500\u59CB\u65E5\u671F\uFF1A");
		label_9.setBounds(263, 90, 82, 15);
		
		JLabel label_10 = new JLabel("\u4FC3\u9500\u6B62\u65E5\u671F\uFF1A");
		label_10.setBounds(497, 90, 82, 15);
		
		JLabel label_11 = new JLabel("\u662F\u5426\u5141\u8BB8\u6253\u6298\uFF1A");
		label_11.setBounds(741, 90, 96, 15);
		
		JLabel label_12 = new JLabel("\u5E93\u5B58\u62A5\u8B66\u6570\u91CF\uFF1A");
		label_12.setBounds(28, 131, 106, 15);
		
		JLabel label_13 = new JLabel("\u8BA1\u5212\u8FDB\u8D27\u6570\uFF1A");
		label_13.setBounds(263, 131, 83, 15);
		
		JLabel label_14 = new JLabel("\u6761\u5F62\u7801\uFF1A");
		label_14.setBounds(497, 131, 82, 15);
		
		textField_8 = new JTextField();
		textField_8.setBounds(95, 87, 123, 21);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBounds(333, 128, 123, 21);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(578, 43, 123, 21);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(135, 131, 83, 21);
		textField_11.setColumns(10);
		
		textField_12 = new JTextField();
		textField_12.setBounds(333, 87, 123, 21);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setBounds(827, 43, 123, 21);
		textField_13.setColumns(10);
		
		JLabel label_15 = new JLabel("\u5907\u6CE8\uFF1A");
		label_15.setBounds(25, 177, 36, 15);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(95, 173, 467, 76);
		
		JButton button_2 = new JButton("\u4FEE\u6539");
		button_2.setBounds(174, 259, 203, 37);
		
		JButton button_3 = new JButton("\u91CD\u7F6E");
		button_3.setBounds(575, 257, 220, 39);
		panel_1.setLayout(null);
		panel_1.add(label_15);
		panel_1.add(textArea);
		panel_1.add(label_3);
		panel_1.add(textField_4);
		panel_1.add(label_8);
		panel_1.add(textField_8);
		panel_1.add(label_12);
		panel_1.add(textField_11);
		panel_1.add(label_4);
		panel_1.add(label_13);
		panel_1.add(label_9);
		panel_1.add(textField_9);
		panel_1.add(textField_12);
		panel_1.add(textField_5);
		panel_1.add(label_6);
		panel_1.add(label_7);
		panel_1.add(label_10);
		panel_1.add(textField_10);
		panel_1.add(textField_6);
		panel_1.add(label_14);
		panel_1.add(textField_13);
		panel_1.add(button_2);
		panel_1.add(label_11);
		panel_1.add(textField_7);
		panel_1.add(button_3);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBounds(578, 128, 123, 21);
		panel_1.add(textField_14);
		
		JRadioButton radioButton = new JRadioButton("\u662F");
		radioButton.setBounds(846, 86, 51, 23);
		panel_1.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("\u5426");
		radioButton_1.setBounds(899, 86, 51, 23);
		panel_1.add(radioButton_1);
		
		JLabel label = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		
		JLabel label_1 = new JLabel("\u5546\u54C1\u540D\u79F0\uFF1A");
		
		JLabel label_5 = new JLabel("\u6761\u5F62\u7801\uFF1A");
		
		JLabel label_2 = new JLabel("\u4F9B\u5E94\u5546\u7F16\u53F7\uFF1A");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		JButton button = new JButton("\u67E5\u627E");
		
		JButton button_1 = new JButton("\u6E05\u7A7A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addGap(85)
							.addComponent(button, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addContainerGap()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)))
					.addGap(16)
					.addComponent(label_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_2)
							.addGap(18)
							.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
							.addGap(40)
							.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE))
						.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE))
					.addGap(130))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(label_5)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(label_1))
					.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(button_1))
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
		
		goodsTable = new JTable();
		goodsTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u7F16\u53F7", "\u5546\u54C1\u540D\u79F0", "\u5546\u54C1\u4EF7\u683C", "\u4F9B\u5E94\u5546\u7F16\u53F7", "\u4FC3\u9500\u4EF7\u683C", "\u4FC3\u9500\u59CB\u65E5\u671F", "\u4FC3\u9500\u6B62\u65E5\u671F", "\u662F\u5426\u5141\u8BB8\u6253\u6298", "\u5E93\u5B58\u62A5\u8B66\u6570\u91CF", "\u8BA1\u5212\u8FDB\u8D27\u6570", "\u6761\u5F62\u7801", "\u5907\u6CE8"
			}
		));
		scrollPane.setViewportView(goodsTable);
		contentPane.setLayout(gl_contentPane);
	}
}
