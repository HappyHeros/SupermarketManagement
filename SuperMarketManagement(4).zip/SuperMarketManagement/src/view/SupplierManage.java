package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.naming.directory.SearchControls;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SupplierManage extends JFrame {

	private JPanel contentPane;
	private JTextField searchTextField;
	private JTable MembersListTable;
	private JTextField editsuplierNameTextField;
	private JTextArea editSupplierInfoTextArea;
	private JTextField editPhoneTextField;
	private JTextField textField;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SupplierManage frame = new SupplierManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SupplierManage() {
		setTitle("\u4F9B\u5E94\u5546\u67E5\u8BE2&\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(8, -31, 792, 590);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u4F9B\u5E94\u5546\u540D\u79F0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(117, 51, 72, 15);
		contentPane.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(80, 88, 617, 249);
		contentPane.add(scrollPane);
		
		MembersListTable = new JTable();
		MembersListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			//	selectedRow(arg0);
			}
		});
		MembersListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"��Ӧ�̱��","��Ӧ������", "��Ӧ�̵绰", "��Ӧ�̵�ַ", "��ע��Ϣ"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		MembersListTable.getColumnModel().getColumn(0).setPreferredWidth(40);
		MembersListTable.getColumnModel().getColumn(1).setPreferredWidth(50);
		MembersListTable.getColumnModel().getColumn(2).setPreferredWidth(50);
		MembersListTable.getColumnModel().getColumn(3).setPreferredWidth(150);
		MembersListTable.getColumnModel().getColumn(4).setPreferredWidth(120);
		
		scrollPane.setViewportView(MembersListTable);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(193, 48, 157, 21);
		contentPane.add(searchTextField);
		searchTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
//��ѯ����
//		searchButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent arg0) {
//				StudentMember serchText= new StudentMember();
//				serchText.setName(searchTextField.getText().toString());
//				setTable(serchText);
//			}
//		});
		searchButton.setBounds(386, 47, 77, 23);
		contentPane.add(searchButton);
		
		JLabel label_1 = new JLabel("\u4F9B\u5E94\u5546\u540D\u79F0\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_1.setBounds(66, 365, 72, 15);
		contentPane.add(label_1);
		
		editsuplierNameTextField = new JTextField();
		editsuplierNameTextField.setColumns(10);
		editsuplierNameTextField.setBounds(136, 362, 130, 21);
		contentPane.add(editsuplierNameTextField);
		
		JLabel label_2 = new JLabel("\u5907\u6CE8\u4FE1\u606F\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_2.setBounds(66, 438, 72, 15);
		contentPane.add(label_2);
		
		editSupplierInfoTextArea = new JTextArea();
		editSupplierInfoTextArea.setLineWrap(true);
		editSupplierInfoTextArea.setTabSize(2);
		editSupplierInfoTextArea.setBounds(136, 439, 381, 90);
		contentPane.add(editSupplierInfoTextArea);
		
		JButton submitEditButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		submitEditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				submitEditAct(arg0);
			}
		});
		submitEditButton.setBounds(587, 400, 101, 23);
		contentPane.add(submitEditButton);
		
		JButton submitDeleteButton = new JButton("\u5220\u9664");
		submitDeleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//deleteMemberAct(e);
			}
		});
		submitDeleteButton.setBounds(587, 478, 101, 23);
		contentPane.add(submitDeleteButton);
		
		JLabel label_3 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_3.setBounds(321, 365, 72, 15);
		contentPane.add(label_3);
		
		editPhoneTextField = new JTextField();
		editPhoneTextField.setColumns(10);
		editPhoneTextField.setBounds(386, 362, 130, 21);
		contentPane.add(editPhoneTextField);
		
		JButton AddnewSupplierButton = new JButton("\u70B9\u51FB\u6DFB\u52A0\u65B0\u7684\u4F9B\u5E94\u5546");
		AddnewSupplierButton.setBounds(488, 39, 190, 39);
		contentPane.add(AddnewSupplierButton);
		
		JLabel label_4 = new JLabel("\u4F9B\u5E94\u5546\u5730\u5740\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_4.setBounds(66, 404, 73, 15);
		contentPane.add(label_4);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(136, 402, 381, 21);
		contentPane.add(textField);
		
		//��ʼ��table
//		setTable(new StudentMember());
	}
	
	//	protected void deleteMemberAct(ActionEvent e) {
	//		// TODO Auto-generated method stub
	//		int index=MembersListTable.getSelectedRow();
	//		if(index==-1) {
	//			JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ���Ķ���");
	//		}else {
	//			int choose=JOptionPane.showConfirmDialog(this, "     ȷ��ɾ��?", "��ʾ", JOptionPane.OK_CANCEL_OPTION);
	//			if(choose!=JOptionPane.YES_OPTION) {				
	//				return;
	//			}
	//			//ȷ��ɾ��
	//			DefaultTableModel dftable=(DefaultTableModel) MembersListTable.getModel();
	//			int id=Integer.parseInt(dftable.getValueAt(MembersListTable.getSelectedRow(), 0).toString());
	//			MemberDao maketDao=new MemberDao();
	//			if(maketDao.delete(id)) {
	//				JOptionPane.showMessageDialog(this, "ɾ���ɹ���");
	//				editMemberNameTextField.setText("");
	//				editMemberInfoTextArea.setText("");
	//				editPhoneTextArea.setText("");
	//			}else {
	//				JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�");
	//			}
	//			setTable(new StudentMember());//ˢ���б�
	//			maketDao.closeDao();	
	//		}
	//		
	//	}

	protected void submitEditAct(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		
	}

	//�����������Ŀ
//	protected void selectedRow(MouseEvent arg0) {
//		// TODO Auto-generated method stub
//		DefaultTableModel dftable=(DefaultTableModel) MembersListTable.getModel();
//		editsuplierNameTextField.setText(dftable.getValueAt(MembersListTable.getSelectedRow(), 1).toString());
//		editSupplierInfoTextArea.setText(dftable.getValueAt(MembersListTable.getSelectedRow(), 2).toString());
//		
//	}
}
