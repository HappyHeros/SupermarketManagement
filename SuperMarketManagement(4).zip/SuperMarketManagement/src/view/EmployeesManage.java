package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.Color;

public class EmployeesManage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeesManage frame = new EmployeesManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeesManage() {
		setTitle("\u5458\u5DE5\u4FE1\u606F\u7BA1\u7406\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 588, 709);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u67E5\u8BE2", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(31, 10, 517, 80);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblid = new JLabel("\u5458\u5DE5ID\uFF1A");
		lblid.setBounds(10, 36, 54, 15);
		panel.add(lblid);
		
		JLabel label = new JLabel("\u5458\u5DE5\u59D3\u540D\uFF1A");
		label.setBounds(226, 36, 65, 15);
		panel.add(label);
		
		textField = new JTextField();
		textField.setBounds(62, 33, 143, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(289, 33, 111, 21);
		panel.add(textField_1);
		
		JButton button_3 = new JButton("\u67E5\u8BE2");
		button_3.setBounds(424, 32, 65, 23);
		panel.add(button_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 112, 517, 183);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5458\u5DE5\u7F16\u53F7", "\u5458\u5DE5\u59D3\u540D", "\u5458\u5DE5\u804C\u4F4D", "\u5458\u5DE5\u51FA\u52E4\u7387", "\u5458\u5DE5\u5165\u804C\u65F6\u95F4", "\u5458\u5DE5\u4E1A\u7EE9"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true, true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u5220\u9664\u5458\u5DE5", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(31, 326, 517, 70);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblid_1 = new JLabel("\u5458\u5DE5ID\uFF1A");
		lblid_1.setBounds(29, 30, 54, 15);
		panel_1.add(lblid_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(93, 27, 234, 21);
		panel_1.add(textField_2);
		textField_2.setColumns(10);
		
		JButton button = new JButton("\u5220\u9664");
		button.setBounds(381, 26, 93, 23);
		panel_1.add(button);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u6DFB\u52A0\u3001\u4FEE\u6539\u5458\u5DE5\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(31, 429, 517, 177);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label_1 = new JLabel("\u5458\u5DE5ID\uFF1A");
		label_1.setBounds(20, 30, 54, 15);
		panel_2.add(label_1);
		
		JLabel label_2 = new JLabel("\u5458\u5DE5\u59D3\u540D\uFF1A");
		label_2.setBounds(20, 57, 65, 15);
		panel_2.add(label_2);
		
		JLabel label_3 = new JLabel("\u5458\u5DE5\u804C\u4F4D\uFF1A");
		label_3.setBounds(20, 82, 65, 15);
		panel_2.add(label_3);
		
		JLabel label_4 = new JLabel("\u5458\u5DE5\u51FA\u52E4\u7387\uFF1A");
		label_4.setBounds(229, 30, 72, 15);
		panel_2.add(label_4);
		
		JLabel label_5 = new JLabel("\u5458\u5DE5\u5165\u804C\u65F6\u95F4\uFF1A");
		label_5.setBounds(229, 57, 84, 15);
		panel_2.add(label_5);
		
		JLabel label_6 = new JLabel("\u5458\u5DE5\u4E1A\u7EE9\uFF1A");
		label_6.setBounds(229, 82, 84, 15);
		panel_2.add(label_6);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(92, 27, 127, 21);
		panel_2.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(92, 54, 127, 21);
		panel_2.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(92, 82, 127, 21);
		panel_2.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(315, 27, 127, 21);
		panel_2.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(315, 54, 127, 21);
		panel_2.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(315, 79, 127, 21);
		panel_2.add(textField_8);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.setBounds(104, 127, 93, 23);
		panel_2.add(button_1);
		
		JButton button_2 = new JButton("\u6E05\u7A7A");
		button_2.setBounds(307, 127, 93, 23);
		panel_2.add(button_2);
	}
}
