package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.naming.directory.SearchControls;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class TradeManage extends JFrame {

	private JPanel contentPane;
	private JTextField searchTextField;
	private JTable ListTable;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TradeManage frame = new TradeManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TradeManage() {
		setTitle("\u4EA4\u6613\u67E5\u8BE2");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 650, 545);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(61, 83, 526, 380);
		contentPane.add(scrollPane);
		
		ListTable = new JTable();
		ListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				selectedRow(arg0);
			}
		});
		ListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"���ױ��", "�û�����", "���׽��","��Ա����","��������","��ע"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		ListTable.getColumnModel().getColumn(0).setPreferredWidth(70);
		ListTable.getColumnModel().getColumn(1).setPreferredWidth(70);
		ListTable.getColumnModel().getColumn(2).setPreferredWidth(70);
		ListTable.getColumnModel().getColumn(3).setPreferredWidth(100);
		ListTable.getColumnModel().getColumn(4).setPreferredWidth(100);
		
		scrollPane.setViewportView(ListTable);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(243, 48, 157, 21);
		contentPane.add(searchTextField);
		searchTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		searchButton.setBounds(454, 47, 77, 23);
		contentPane.add(searchButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u4EA4\u6613\u7F16\u53F7", "\u7528\u6237\u540D\u79F0", "\u4F1A\u5458\u5361\u53F7"}));
		comboBox.setBounds(156, 47, 77, 23);
		contentPane.add(comboBox);
		
	}

	protected void selectedRow(MouseEvent arg0) {
		
	}

}
