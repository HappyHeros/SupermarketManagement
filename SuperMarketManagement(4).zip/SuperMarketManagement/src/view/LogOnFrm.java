package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class LogOnFrm extends JFrame {

	private JPanel contentPane;
	private JTextField userName_Text;
	private JTextField passport_Text;
	private JComboBox userTypebox; 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String lookAndFeel = UIManager.getSystemLookAndFeelClassName(); 
					UIManager.setLookAndFeel(lookAndFeel);	//�������
					LogOnFrm frame = new LogOnFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogOnFrm() {
		setTitle("\u767B\u5F55\u754C\u9762");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 329);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);	//������ʾ
		
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setBounds(95, 103, 56, 16);
		label.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel label_1 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_1.setBounds(95, 151, 56, 16);
		label_1.setFont(new Font("����", Font.PLAIN, 14));
		
		userName_Text = new JTextField();
		userName_Text.setBounds(177, 101, 161, 21);
		userName_Text.setColumns(10);
		
		passport_Text = new JTextField();
		passport_Text.setBounds(177, 149, 161, 21);
		passport_Text.setColumns(10);
		
		JLabel label_2 = new JLabel("\u7528\u6237\u7C7B\u578B\uFF1A");
		label_2.setBounds(125, 193, 60, 17);
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		
		userTypebox = new JComboBox();
		userTypebox.setBounds(201, 191, 103, 21);
		userTypebox.setModel(new DefaultComboBoxModel(new String[] {"����Ա","����Ա"}));
		
		JButton loginButton = new JButton("\u767B\u5F55");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				loginAct(arg0);
			}
		});
		loginButton.setBounds(100, 234, 64, 23);
		
		JButton exitButton = new JButton("\u9000\u51FA");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		exitButton.setBounds(256, 234, 64, 23);
		
		contentPane.setLayout(null);
		contentPane.add(label_2);
		contentPane.add(userTypebox);
		contentPane.add(loginButton);
		contentPane.add(exitButton);
		contentPane.add(label);
		contentPane.add(label_1);
		contentPane.add(passport_Text);
		contentPane.add(userName_Text);
		
		JLabel lblCh = new JLabel("���й���ϵͳ��¼");
		lblCh.setIcon(new ImageIcon(LogOnFrm.class.getResource("/IconForSuperMarket/maket.png")));
		lblCh.setFont(new Font("΢���ź�", Font.BOLD, 18));
		lblCh.setBounds(111, 32, 227, 47);
		contentPane.add(lblCh);
	}

	//�û���¼����
	protected void loginAct(ActionEvent arg0) {
//		// TODO Auto-generated method stub
//		String userName=userName_Text.getText().toString();
//		String password=passport_Text.getText().toString();
//		UserType selectedItem=(UserType)userTypebox.getSelectedItem();
//		if(StringUtil.isEmpty(userName)) {
//			JOptionPane.showMessageDialog(this, "�������û�����");
//			return;
//		}
//		if(StringUtil.isEmpty(password)) {
//			JOptionPane.showMessageDialog(this, "���������룡");
//			return;
//		}
//		
//		Admin admin =null;
		//��ͬ���û����͵�¼
//		if("ϵͳ����Ա".equals(selectedItem.getName())) {
//			AdminDao adminDao=new AdminDao();
//			Admin adminTmp =new Admin();
//			adminTmp.setName(userName);
//			adminTmp.setPassword(password);
//			admin =adminDao.login(adminTmp);
//			adminDao.closeDao();
//			if(admin==null) {
//				JOptionPane.showMessageDialog(this, "�û����������");
//				return;
//			}else {
//				JOptionPane.showMessageDialog(this, "��"+selectedItem.getName()+"��:"+admin.getName()+"  ��¼�ɹ���");
//				this.dispose();//�˳���¼����  
//				MainJFM mainJFM=new MainJFM(selectedItem, admin);
////				mainJFM.setLocation((int) (width - mainJFM.getWidth()) / 2,(int) (height - mainJFM.getHeight()) / 2);//���е���λ��
//				mainJFM.setVisible(true);
//			}
//			
//		}else {
//			
//			
//		}
		
	}
}
