package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class StockManage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTable table;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StockManage frame = new StockManage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StockManage() {
		setTitle("\u5E93\u5B58\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 853, 635);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u67E5\u8BE2\u5E93\u5B58", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(34, 32, 756, 88);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u5165\u5E93\u7F16\u53F7\uFF1A");
		label.setBounds(48, 20, 89, 22);
		panel.add(label);
		
		JLabel label_1 = new JLabel("\u5165\u5E93\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_1.setBounds(48, 56, 89, 22);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("\u5165\u5E93\u65E5\u671F\uFF1A");
		label_2.setBounds(345, 20, 77, 22);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("\u5165\u5E93\u72B6\u6001\uFF1A");
		label_3.setBounds(345, 56, 77, 22);
		panel.add(label_3);
		
		textField = new JTextField();
		textField.setBounds(168, 21, 167, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(168, 57, 167, 21);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(423, 21, 149, 21);
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(423, 58, 149, 21);
		panel.add(textField_3);
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.setBounds(601, 20, 93, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("\u6E05\u7A7A");
		button_1.setBounds(601, 56, 93, 23);
		panel.add(button_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 145, 756, 208);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5165\u5E93\u7F16\u53F7", "\u5165\u5E93\u5546\u54C1\u7F16\u53F7", "\u5165\u5E93\u6570\u91CF", "\u5355\u989D", "\u603B\u989D", "\u5165\u5E93\u65E5\u671F", "\u8BA1\u5212\u8FDB\u8D27\u65E5\u671F", "\u5165\u5E93\u72B6\u6001", "\u5907\u6CE8"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true, true, true, false, false, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u4FEE\u6539\u5E93\u5B58\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(34, 380, 756, 178);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label_4 = new JLabel("\u5165\u5E93\u7F16\u53F7\uFF1A");
		label_4.setBounds(34, 32, 89, 22);
		panel_1.add(label_4);
		
		JLabel label_5 = new JLabel("\u5165\u5E93\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_5.setBounds(34, 64, 89, 22);
		panel_1.add(label_5);
		
		JLabel label_6 = new JLabel("\u5165\u5E93\u6570\u91CF\uFF1A");
		label_6.setBounds(34, 96, 89, 22);
		panel_1.add(label_6);
		
		textField_4 = new JTextField();
		textField_4.setBounds(125, 33, 134, 21);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(125, 64, 134, 21);
		panel_1.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(125, 97, 134, 21);
		panel_1.add(textField_6);
		
		JLabel label_7 = new JLabel("\u5355\u989D\uFF1A");
		label_7.setBounds(275, 32, 67, 22);
		panel_1.add(label_7);
		
		JLabel label_8 = new JLabel("\u603B\u989D\uFF1A");
		label_8.setBounds(275, 64, 67, 22);
		panel_1.add(label_8);
		
		JLabel label_9 = new JLabel("\u5165\u5E93\u65E5\u671F\uFF1A");
		label_9.setBounds(275, 96, 67, 22);
		panel_1.add(label_9);
		
		JLabel label_10 = new JLabel("\u8BA1\u5212\u8FDB\u8D27\u65E5\u671F\uFF1A");
		label_10.setBounds(477, 32, 109, 22);
		panel_1.add(label_10);
		
		JLabel label_11 = new JLabel("\u5165\u5E93\u72B6\u6001\uFF1A");
		label_11.setBounds(477, 64, 67, 22);
		panel_1.add(label_11);
		
		JLabel label_12 = new JLabel("\u5907\u6CE8\uFF1A");
		label_12.setBounds(477, 96, 67, 22);
		panel_1.add(label_12);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(333, 33, 134, 21);
		panel_1.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(333, 65, 134, 21);
		panel_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(333, 97, 134, 21);
		panel_1.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(569, 33, 148, 21);
		panel_1.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(569, 65, 148, 21);
		panel_1.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(521, 97, 196, 50);
		panel_1.add(textField_12);
		
		JButton button_2 = new JButton("\u589E\u52A0");
		button_2.setBounds(34, 145, 93, 23);
		panel_1.add(button_2);
		
		JButton button_3 = new JButton("\u5220\u9664");
		button_3.setBounds(165, 145, 93, 23);
		panel_1.add(button_3);
		
		JButton button_4 = new JButton("\u4FEE\u6539");
		button_4.setBounds(296, 145, 93, 23);
		panel_1.add(button_4);
		
		JButton button_5 = new JButton("\u6E05\u7A7A\u8F93\u5165");
		button_5.setBounds(418, 145, 93, 23);
		panel_1.add(button_5);
	}
}
